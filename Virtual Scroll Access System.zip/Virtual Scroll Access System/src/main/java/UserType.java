public enum UserType {
    ADMIN,
    REGISTERED_USER,
    GUEST;
}
